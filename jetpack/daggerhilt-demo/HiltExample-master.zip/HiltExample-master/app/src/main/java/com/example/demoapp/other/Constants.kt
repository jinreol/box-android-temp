package com.example.demoapp.other

object Constants {

    const val BASE_URL = "http://dummy.restapiexample.com/api/v1/"

}