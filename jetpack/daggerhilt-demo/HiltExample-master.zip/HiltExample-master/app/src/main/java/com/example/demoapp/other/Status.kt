package com.example.demoapp.other

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}